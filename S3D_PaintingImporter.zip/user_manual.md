# Smart3D Painting Importer 用户手册 (V2.0)

`S3D_PaintingImporter` 是专为 Smart3D 设计的批量属性导入插件，支持通过 Excel 一次性写入涂装（Coating）、扩展涂层（Extended Coating）和检测（Testing）三类接口属性，并内置"写入-读回"双向验证机制。

---

## 快速启动

1. 在 S3D 命令行输入 `S3D_PaintingImporter.ImporterCommand` 启动工具。
2. 点击左侧 **Select Excel File** 选择填写好的 Excel 导入文件。
3. 点击 **Start Execution** 执行导入，实时日志在右侧窗口显示。

---

## Excel 数据规范

### 列名约定

工具以**首行列名**匹配字段，列顺序无要求，不需要的列可以省略。

| 列名 | 对应接口 | S3D 属性类型 | 说明 |
| :--- | :--- | :--- | :--- |
| `ObjectName` | — | — | S3D 对象名称，**必填**，用于定位管线或设备 |
| `CoatingRequirement` | `IJCoatingInfo` | Codelist | 涂装要求 |
| `CoatingType` | `IJCoatingInfo` | Codelist | 涂装类型 |
| `CleaningRequirement` | `IJRteRouteExtendedCoating` | Codelist | 清洁要求 |
| `TestingPercentage` | `IJRteTesting` | Float | 检测百分比（填数字，如 `5`） |
| `TestingRequirements` | `IJRteTesting` | Codelist | 检测要求 |
| `TestingType` | `IJRteTesting` | Codelist | 检测类型 |

> 工具同时兼容旧版三列格式（A=ObjectName、B=CoatingRequirement、C=CoatingType），无需修改历史文件。

### Codelist 填写格式

Codelist 属性在 S3D 数据库中存储的是整数 ID。支持以下两种写法，工具会自动识别：

| 写法 | 示例 | 说明 |
| :--- | :--- | :--- |
| 名称 (ID) | `CC1 (10)` | 自动提取括号内的数字 `10` |
| 纯数字 | `10` | 直接使用 |

### Float / Double 填写格式

使用英文小数点，例如 `5` 或 `12.5`，不要包含单位或其他字符。

### 示例数据行

| ObjectName | CoatingRequirement | CoatingType | CleaningRequirement | TestingPercentage | TestingRequirements | TestingType |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| GDP34-100-APR-0001 | Painting (10) | PS1.04 (4) | CC1 (10) | 5 | Welds (15) | Radiographic (55) |

---

## 日志颜色说明

| 颜色 | 含义 | 示例 |
| :--- | :--- | :--- |
| 绿色 | 写入成功并验证通过 | `[DONE] Line-001 processed.` |
| 蓝色 | 正在执行的操作 | `Searching for object: Line-001` |
| 白色 | 常规信息 | `Transaction Committed to Database.` |
| 红色 | 警告或错误 | `Warning: Object not found` |

验证日志格式：`Set TestingType = 55 (Verify: Radiographic)` 表示写入 ID 55 后从 S3D 读回确认描述为 Radiographic。

---

## 常见问题

### 属性写入后被还原？
部分对象受 S3D 自动化规则保护，工具已自动尝试设置 `PartOverride` 标志。如仍被还原，请在 S3D 中确认对象是否已被其他用户 Claim 或受权限组独占。

### 某些行显示红色但其他行成功？
- 检查 Excel 单元格是否含有隐藏换行符或全角空格。
- 检查该对象在 S3D 中是否挂载了对应接口（如 `IJRteTesting`），部分管道规格可能未配置检测接口。

### 大批量导入界面无响应？
S3D COM 对象必须在主线程访问，属于正常现象。进度条会持续更新，处理完成后界面自动恢复。建议单次导入不超过 **2,000 条**，超出时按 1,000 条拆分分批执行。

### 日志提示 `Attribute Error`？
常见原因：该属性对当前用户为只读，或 S3D 对象类型未实现该接口。可在 S3D 属性窗口确认对应接口是否存在。

---

## 操作建议

- 导入前备份 S3D 数据库快照。
- 先用少量数据（5~10 条）试运行，确认日志全绿后再批量执行。
- 日志文件自动保存至工具 DLL 同目录的 `Logs\` 文件夹，格式为 `PaintingImport_yyyyMMdd_HHmmss.log`。

---

*© 2026 Smart3D 自动化专家团队*
